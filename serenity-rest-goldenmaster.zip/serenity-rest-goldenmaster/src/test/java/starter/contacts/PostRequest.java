package starter.contacts;

import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.util.EnvironmentVariables;
import net.thucydides.core.util.SystemEnvironmentVariables;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import static org.assertj.core.api.Assertions.assertThat;
import static starter.WebServiceEndPoints.STATUS;

public class PostRequest {

    ResponseBody body;
    String testenvironment;

    @Step("Get current status")
    public void currentStatus() {
        int statusCode=0;
        statusCode = SerenityRest
                .get(STATUS.getUrl())
                .statusCode();
        assertThat(statusCode).isEqualTo(401);
    }

    @Step("sendPostRequest APIPath={0}  and fileName={1}")
    public void sendPostRequest(String APIPath, String fileName)
    {
        String StrBody="";
        StrBody=GetResponseBodyFromFile("Requestbody/"+fileName);

        /*SerenityRest.when()
                .get("v1/support/contacts/account/3/user/2/operators/true")
                .Ensure.that("")
                .then().body("", Matchers.equalTo(""));*/

        Response response =SerenityRest.given().baseUri(STATUS.getUrl())
                .auth().basic("admin","release2018")
                .body(StrBody)
                //.get("v1/support/contacts/account/3/user/2/operators/true")
                .post(APIPath);

        assertThat(response.statusCode()).isEqualTo(200);
        // Retrieve the body of the Response
         body = response.getBody();

        String runmode="";
        EnvironmentVariables variables = SystemEnvironmentVariables.createEnvironmentVariables();
        runmode = variables.getProperty("serenity.run.mode");
        testenvironment = variables.getProperty("serenity.testenvironment");


    }

    @Step("Get validateResponse fileName={0}")
    public void validateResponse(String fileName) {
        String content ="";
        content = GetResponseBodyFromFile(fileName);
        assertThat(body.asString()).isEqualTo(content);
    }

    private void SaveResponseBody(ResponseBody body, String fileName) {
        FileWriter file ;
        try {
            file = new FileWriter("./src/data/" +testenvironment +"/" +fileName);
            file.write(body.asString());
            //file.write(body.prettyPrint());
            file.flush();
            file.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String GetResponseBodyFromFile( String fileName) {
        String content="";
        try {
            content = new String(Files.readAllBytes(Paths.get("./src/data/" +testenvironment +"/" +fileName)));

        } catch (IOException e) {
            e.printStackTrace();
        }
        return content;
    }

    @Step("Get validateStatus")
    public void validateStatus() {
    }
}
