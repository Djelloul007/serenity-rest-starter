package starter.status;

import io.restassured.RestAssured;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static starter.WebServiceEndPoints.STATUS;
import static net.serenitybdd.rest.SerenityRest.restAssuredThat;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static starter.status.AppStatus.RUNNING;
public class ApplicationStatus {

    @Step("Get current status")
    public void currentStatus() {
        int statusCode = SerenityRest.get(STATUS.getUrl()).statusCode();
        assertThat(statusCode).isEqualTo(401);

        SerenityRest.given().auth().basic("admin","release2018").get(STATUS.getUrl()).statusCode();
        assertThat(statusCode).isEqualTo(200);

    }

    @Step("Get current status message")
    public void readStatusMessage() {
        //SerenityRest.get(STATUS.getUrl());
    }
}
