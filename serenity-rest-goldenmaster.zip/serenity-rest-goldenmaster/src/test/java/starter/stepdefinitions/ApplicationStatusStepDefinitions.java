package starter.stepdefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import net.thucydides.core.annotations.Steps;
import starter.contacts.GetApiResponse;
import starter.contacts.PostRequest;
import starter.status.ApplicationStatus;



public class ApplicationStatusStepDefinitions {

    @Steps
    ApplicationStatus theApplication;

    @Steps
    GetApiResponse getApiResponse;

    @Steps
    PostRequest postRequest;



    @Given("the application is running")
    public void the_application_is_running() {

    }

    @When("I check this APIPath (.*) or save response to (.*)")
    public void i_check_the_contactListe(String APIPath,String FileName) {
        getApiResponse.getcontactListe(APIPath,FileName);
    }

    @Then("the API should return a valid Response which match with this file (.*)")
    public void the_API_should_return_a_valid_contact_Liste(String FileName) {
        getApiResponse.validateResponse(FileName);
    }

    @When("I Send this Post Request (.*) or save response to (.*)")
    public void I_Send_this_Post_Request(String APIPath,String FileName) {
        postRequest.sendPostRequest(APIPath,FileName);
    }

    @Then("the API should return a valid Status")
    public void the_API_should_return_a_valid_Status() {
        postRequest.validateStatus();
    }
}
